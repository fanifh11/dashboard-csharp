﻿using LiveCharts;
using LiveCharts.Wpf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DashboardVisual.Properties
{
    
  

    public partial class Form1 : Form
    {
        OleDbCommand oleDbCmd = new OleDbCommand();
        String connParam = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\ASUS\source\repos\DashboardVisual\DashboardVisual\bin\Debug\Eks.mdb;Persist Security Info=False";
        
        
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
    (
        int nLeftRect,     // x-coordinate of upper-left corner
        int nTopRect,      // y-coordinate of upper-left corner
        int nRightRect,    // x-coordinate of lower-right corner
        int nBottomRect,   // y-coordinate of lower-right corner
        int nWidthEllipse, // height of ellipse
        int nHeightEllipse // width of ellipse
    );
        public Form1()
        {
            InitializeComponent();
            cartesianChart1.Series = new SeriesCollection
            {
                new ColumnSeries
                {
                    Title = "2016",
                    Values = new ChartValues<double> { 520, 330 , 239, 190 }
                }
            };

            //adding series will update and animate the chart automatically
            cartesianChart1.Series.Add(new ColumnSeries
            {
                Title = "2017",
                Values = new ChartValues<double> { 800, 543, 356, 242 }
            });

            cartesianChart1.Series.Add(new ColumnSeries
            {
                Title = "2018",
                Values = new ChartValues<double> { 711, 423, 213, 156 }
            });

            cartesianChart1.Series.Add(new ColumnSeries
            {
                Title = "2019",
                Values = new ChartValues<double> { 912, 356, 240, 321 }
            });

            cartesianChart1.Series.Add(new ColumnSeries
            {
                Title = "2020",
                Values = new ChartValues<double> { 871, 351, 189, 204 }
            });



            cartesianChart1.AxisX.Add(new Axis
            {
                Title = "Jasa Pengiriman",
                Labels = new[] { "Reguler", "Kliat", "SuperKilat", "Ekspres"}
            });

            cartesianChart1.AxisY.Add(new Axis
            {
                Title = "Sold Apps",
                LabelFormatter = value => value.ToString("N")
            });


            int hrd = 0;
            int cs = 0;
            int kurir = 0;
            int dll = 0;

            // load data dari database 
            using (OleDbConnection connection = new OleDbConnection(connParam))
            {
                // buat query dan koneksikan ke db
                OleDbCommand command = new OleDbCommand("select * from jumlah_pegawai", connection);
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();

                // fetch data
                while (reader.Read())
                {
                    hrd = reader.GetInt32(1);
                    cs = reader.GetInt32(2);
                    kurir = reader.GetInt32(3);
                    dll = reader.GetInt32(4);
                }
                // always call Close when done reading.
                reader.Close();
            }

            Func<ChartPoint, string> labelPoint = chartPoint =>
                string.Format("{0} ({1:P})", chartPoint.Y, chartPoint.Participation);

            pieChart1.Series = new SeriesCollection
            {
                new PieSeries
                {
                    Title = "Lain - lain",
                    Values = new ChartValues<double> {dll},
                    PushOut = 15,
                    DataLabels = true,
                    LabelPoint = labelPoint
                },
                new PieSeries
                {
                    Title = "Customer Service",
                    Values = new ChartValues<double> {cs},
                    DataLabels = true,
                    LabelPoint = labelPoint
                },
                new PieSeries
                {
                    Title = "Kurir",
                    Values = new ChartValues<double> {kurir},
                    DataLabels = true,
                    LabelPoint = labelPoint
                },
                new PieSeries
                {
                    Title = "HRD",
                    Values = new ChartValues<double> {hrd},
                    DataLabels = true,
                    LabelPoint = labelPoint
                }
            };

            pieChart1.LegendLocation = LegendLocation.Bottom;



            int makanan = 0;
            int dokumen = 0;
            int buku = 0;
            int elektronik = 0;
            int pakaian = 0;

            // load data dari database 
            using (OleDbConnection connection = new OleDbConnection(connParam))
            {
                // buat query dan koneksikan ke db
                OleDbCommand command = new OleDbCommand("select * from jumlah_barang ", connection);
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();

                // fetch data
                while (reader.Read())
                {
                    makanan = reader.GetInt32(5);
                    dokumen = reader.GetInt32(4);
                    buku = reader.GetInt32(1);
                    elektronik = reader.GetInt32(2);
                    pakaian = reader.GetInt32(3);
                }
                // always call Close when done reading.
                reader.Close();
            }

            pieChart2.Series = new SeriesCollection
            {
                new PieSeries
                {
                    Title = "Makanan",
                    Values = new ChartValues<double> {makanan},
                    PushOut = 15,
                    DataLabels = true,
                    LabelPoint = labelPoint
                },
                new PieSeries
                {
                    Title = "Elektronik",
                    Values = new ChartValues<double> {elektronik},
                    DataLabels = true,
                    LabelPoint = labelPoint
                },
                new PieSeries
                {
                    Title = "Buku",
                    Values = new ChartValues<double> {buku},
                    DataLabels = true,
                    LabelPoint = labelPoint
                },
                new PieSeries
                {
                    Title = "Pakaian",
                    Values = new ChartValues<double> {pakaian},
                    DataLabels = true,
                    LabelPoint = labelPoint
                },
            
           
            };

            pieChart2.LegendLocation = LegendLocation.Bottom;


        
            pieChart3.Series = new SeriesCollection
            {
                new PieSeries
                {
                    Title = "Barang Diterima",
                    Values = new ChartValues<double> {60},
                    PushOut = 10,
                    DataLabels = true,
                    LabelPoint = labelPoint
                },
                new PieSeries
                {
                    Title = "Barang Dikirim",
                    Values = new ChartValues<double> {40},
                    DataLabels = true,
                    LabelPoint = labelPoint
                }
                
            };

            pieChart3.LegendLocation = LegendLocation.Bottom;


            int cod = 0;
            int tunai = 0;

            // load data dari database 
            using (OleDbConnection connection = new OleDbConnection(connParam))
            {
                // buat query dan koneksikan ke db
                OleDbCommand command = new OleDbCommand("select * from jumlah_barang ", connection);
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();

                // fetch data
                while (reader.Read())
                {
                    cod = reader.GetInt32(1);
                    tunai = reader.GetInt32(2);

                }
                // always call Close when done reading.
                reader.Close();
            }

            pieChart4.Series = new SeriesCollection
            {
                new PieSeries
                {
                    Title = "Pembayaran Tunai",
                    Values = new ChartValues<double> {tunai},
                    PushOut = 10,
                    DataLabels = true,
                    LabelPoint = labelPoint
                },
                new PieSeries
                {
                    Title = "Pembayaran Non-Tunai (COD)",
                    Values = new ChartValues<double> {cod},
                    DataLabels = true,
                    LabelPoint = labelPoint
                }

            };

            pieChart4.LegendLocation = LegendLocation.Bottom;


            pieChart5.InnerRadius = 86;
            pieChart5.LegendLocation = LegendLocation.Right;

            pieChart5.Series = new SeriesCollection
            {
                new PieSeries
                {
                    Title = "Suka",
                    Values = new ChartValues<double> {55},
                    PushOut = 8,
                    DataLabels = true
                },
                new PieSeries
                {
                    Title = "Tidak Suka",
                    Values = new ChartValues<double> {30},
                    DataLabels = true
                },
                  new PieSeries
                {
                    Title = "Tanpa Responsi",
                    Values = new ChartValues<double> {15},
                    DataLabels = true
                },

            };


            

   

            


    


        }

        private void gradientPanel1_Paint(object sender, PaintEventArgs e)
        {
            gradientPanel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, gradientPanel1.Width, gradientPanel1.Height, 30, 30));
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'eksDataSet.QTarif' table. You can move, or remove it, as needed.
            this.qTarifTableAdapter.Fill(this.eksDataSet.QTarif);
            // TODO: This line of code loads data into the 'eksDataSet.QPembayaran' table. You can move, or remove it, as needed.
            this.qPembayaranTableAdapter.Fill(this.eksDataSet.QPembayaran);
            // TODO: This line of code loads data into the 'eksDataSet.QTotal_barang' table. You can move, or remove it, as needed.
            this.qTotal_barangTableAdapter.Fill(this.eksDataSet.QTotal_barang);
            // TODO: This line of code loads data into the 'eksDataSet.QJumlahKurir' table. You can move, or remove it, as needed.
            this.qJumlahKurirTableAdapter.Fill(this.eksDataSet.QJumlahKurir);
            // TODO: This line of code loads data into the 'eksDataSet.Qjabatan' table. You can move, or remove it, as needed.
            this.qjabatanTableAdapter.Fill(this.eksDataSet.Qjabatan);
            // TODO: This line of code loads data into the 'eksDataSet1.Qjabatan' table. You can move, or remove it, as needed.

            // TODO: This line of code loads data into the 'ekspedisiDataSet.QTotal_barang' table. You can move, or remove it, as needed.

            DataTable dt = new DataTable();
 
            dt.Columns.Add(" ");
            dt.Columns.Add("Reguler" );
            dt.Columns.Add("Kilat");
            dt.Columns.Add("SuperKilat");
            dt.Columns.Add("Ekspres");

            dt.Rows.Add("2016", "520", "330", "239", "190");
            dt.Rows.Add("2017" , "800", "543", "356", "242");
            dt.Rows.Add("2018", "711", "423", "213", "156");
            dt.Rows.Add("2019", "912" , "356" , "240" , "321");
            dt.Rows.Add("2020", "871", "351", "189", "204");

            dataGridView1.DataSource = dt;



        }

        private void gradientPanel2_Paint(object sender, PaintEventArgs e)
        {
            gradientPanel2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, gradientPanel2.Width, gradientPanel2.Height, 30, 30));
        }

        private void gradientPanel3_Paint(object sender, PaintEventArgs e)
        {
            gradientPanel3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, gradientPanel3.Width, gradientPanel3.Height, 30, 30));
        }

        private void cartesianChart1_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pieChart1_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

        }

        private void gradientPanel4_Paint(object sender, PaintEventArgs e)
        {
            gradientPanel4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, gradientPanel4.Width, gradientPanel4.Height, 30, 30));
        }

        private void pieChart2_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

        }

        private void gradientPanel5_Paint(object sender, PaintEventArgs e)
        {
            gradientPanel5.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, gradientPanel5.Width, gradientPanel5.Height, 30, 30));

        }

        private void pieChart3_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

        }

        private void gradientPanel6_Paint(object sender, PaintEventArgs e)
        {
            gradientPanel6.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, gradientPanel6.Width, gradientPanel6.Height, 30, 30));

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pieChart4_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

        }

        private void gradientPanel7_Paint(object sender, PaintEventArgs e)
        {
            gradientPanel7.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, gradientPanel7.Width, gradientPanel7.Height, 30, 30));
        }

        private void pieChart5_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

        }

        private void gradientPanel9_Paint(object sender, PaintEventArgs e)
        {
            gradientPanel9.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, gradientPanel9.Width, gradientPanel9.Height, 30, 30));
        }

        private void gradientPanel10_Paint(object sender, PaintEventArgs e)
        {
            gradientPanel10.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, gradientPanel10.Width, gradientPanel10.Height, 30, 30));
        }

    
    }
}
