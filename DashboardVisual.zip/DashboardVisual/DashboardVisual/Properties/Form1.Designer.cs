﻿namespace DashboardVisual.Properties
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            this.eksDataSet = new DashboardVisual.EksDataSet();
            this.qjabatanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.qjabatanTableAdapter = new DashboardVisual.EksDataSetTableAdapters.QjabatanTableAdapter();
            this.qJumlahKurirBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.qJumlahKurirTableAdapter = new DashboardVisual.EksDataSetTableAdapters.QJumlahKurirTableAdapter();
            this.qTotalbarangBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.qTotal_barangTableAdapter = new DashboardVisual.EksDataSetTableAdapters.QTotal_barangTableAdapter();
            this.qPembayaranBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.qPembayaranTableAdapter = new DashboardVisual.EksDataSetTableAdapters.QPembayaranTableAdapter();
            this.qTarifBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.qTarifTableAdapter = new DashboardVisual.EksDataSetTableAdapters.QTarifTableAdapter();
            this.gradientPanel10 = new DashboardVisual.GradientPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.metroGrid5 = new MetroFramework.Controls.MetroGrid();
            this.namajenispengirimanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.biayaKirimDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jumlahTransaksiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalPemasukkanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.gradientPanel9 = new DashboardVisual.GradientPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.pieChart5 = new LiveCharts.WinForms.PieChart();
            this.gradientPanel8 = new DashboardVisual.GradientPanel();
            this.label12 = new System.Windows.Forms.Label();
            this.gradientPanel7 = new DashboardVisual.GradientPanel();
            this.metroGrid4 = new MetroFramework.Controls.MetroGrid();
            this.jenispembayaranDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jumlahDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pieChart4 = new LiveCharts.WinForms.PieChart();
            this.gradientPanel6 = new DashboardVisual.GradientPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pieChart3 = new LiveCharts.WinForms.PieChart();
            this.gradientPanel5 = new DashboardVisual.GradientPanel();
            this.metroGrid3 = new MetroFramework.Controls.MetroGrid();
            this.jenisBarangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jumlahDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.pieChart2 = new LiveCharts.WinForms.PieChart();
            this.gradientPanel4 = new DashboardVisual.GradientPanel();
            this.metroGrid2 = new MetroFramework.Controls.MetroGrid();
            this.namajabatanDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.keteranganDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jumlahKurirDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.namajabatanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.keteranganDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jumahDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.pieChart1 = new LiveCharts.WinForms.PieChart();
            this.gradientPanel3 = new DashboardVisual.GradientPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cartesianChart1 = new LiveCharts.WinForms.CartesianChart();
            this.gradientPanel2 = new DashboardVisual.GradientPanel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.gradientPanel1 = new DashboardVisual.GradientPanel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.eksDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qjabatanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qJumlahKurirBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qTotalbarangBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qPembayaranBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qTarifBindingSource)).BeginInit();
            this.gradientPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.gradientPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.gradientPanel8.SuspendLayout();
            this.gradientPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.gradientPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.gradientPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).BeginInit();
            this.gradientPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            this.gradientPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.gradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.gradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // eksDataSet
            // 
            this.eksDataSet.DataSetName = "EksDataSet";
            this.eksDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // qjabatanBindingSource
            // 
            this.qjabatanBindingSource.DataMember = "Qjabatan";
            this.qjabatanBindingSource.DataSource = this.eksDataSet;
            // 
            // qjabatanTableAdapter
            // 
            this.qjabatanTableAdapter.ClearBeforeFill = true;
            // 
            // qJumlahKurirBindingSource
            // 
            this.qJumlahKurirBindingSource.DataMember = "QJumlahKurir";
            this.qJumlahKurirBindingSource.DataSource = this.eksDataSet;
            // 
            // qJumlahKurirTableAdapter
            // 
            this.qJumlahKurirTableAdapter.ClearBeforeFill = true;
            // 
            // qTotalbarangBindingSource
            // 
            this.qTotalbarangBindingSource.DataMember = "QTotal_barang";
            this.qTotalbarangBindingSource.DataSource = this.eksDataSet;
            // 
            // qTotal_barangTableAdapter
            // 
            this.qTotal_barangTableAdapter.ClearBeforeFill = true;
            // 
            // qPembayaranBindingSource
            // 
            this.qPembayaranBindingSource.DataMember = "QPembayaran";
            this.qPembayaranBindingSource.DataSource = this.eksDataSet;
            // 
            // qPembayaranTableAdapter
            // 
            this.qPembayaranTableAdapter.ClearBeforeFill = true;
            // 
            // qTarifBindingSource
            // 
            this.qTarifBindingSource.DataMember = "QTarif";
            this.qTarifBindingSource.DataSource = this.eksDataSet;
            // 
            // qTarifTableAdapter
            // 
            this.qTarifTableAdapter.ClearBeforeFill = true;
            // 
            // gradientPanel10
            // 
            this.gradientPanel10.ColorBottom = System.Drawing.Color.Cyan;
            this.gradientPanel10.ColorTop = System.Drawing.Color.SkyBlue;
            this.gradientPanel10.Controls.Add(this.label14);
            this.gradientPanel10.Controls.Add(this.metroGrid5);
            this.gradientPanel10.Controls.Add(this.pictureBox6);
            this.gradientPanel10.Controls.Add(this.label13);
            this.gradientPanel10.Location = new System.Drawing.Point(64, 1620);
            this.gradientPanel10.Name = "gradientPanel10";
            this.gradientPanel10.Size = new System.Drawing.Size(890, 382);
            this.gradientPanel10.TabIndex = 8;
            this.gradientPanel10.Paint += new System.Windows.Forms.PaintEventHandler(this.gradientPanel10_Paint);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(215, 118);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(298, 48);
            this.label14.TabIndex = 4;
            this.label14.Text = "Berikut adalah total pemasukkan\r\nper tanggal yang sudah ditentukan";
            // 
            // metroGrid5
            // 
            this.metroGrid5.AllowUserToAddRows = false;
            this.metroGrid5.AllowUserToDeleteRows = false;
            this.metroGrid5.AllowUserToResizeRows = false;
            this.metroGrid5.AutoGenerateColumns = false;
            this.metroGrid5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.metroGrid5.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.metroGrid5.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid5.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid5.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.metroGrid5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.namajenispengirimanDataGridViewTextBoxColumn,
            this.biayaKirimDataGridViewTextBoxColumn,
            this.jumlahTransaksiDataGridViewTextBoxColumn,
            this.totalPemasukkanDataGridViewTextBoxColumn});
            this.metroGrid5.DataSource = this.qTarifBindingSource;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid5.DefaultCellStyle = dataGridViewCellStyle17;
            this.metroGrid5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.metroGrid5.EnableHeadersVisualStyles = false;
            this.metroGrid5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid5.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid5.Location = new System.Drawing.Point(0, 233);
            this.metroGrid5.Name = "metroGrid5";
            this.metroGrid5.ReadOnly = true;
            this.metroGrid5.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid5.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.metroGrid5.RowHeadersWidth = 51;
            this.metroGrid5.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid5.RowTemplate.Height = 24;
            this.metroGrid5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid5.Size = new System.Drawing.Size(890, 149);
            this.metroGrid5.TabIndex = 5;
            // 
            // namajenispengirimanDataGridViewTextBoxColumn
            // 
            this.namajenispengirimanDataGridViewTextBoxColumn.DataPropertyName = "Nama_jenis_pengiriman";
            this.namajenispengirimanDataGridViewTextBoxColumn.HeaderText = "Tarif Pengiriman";
            this.namajenispengirimanDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.namajenispengirimanDataGridViewTextBoxColumn.Name = "namajenispengirimanDataGridViewTextBoxColumn";
            this.namajenispengirimanDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // biayaKirimDataGridViewTextBoxColumn
            // 
            this.biayaKirimDataGridViewTextBoxColumn.DataPropertyName = "Biaya Kirim";
            this.biayaKirimDataGridViewTextBoxColumn.HeaderText = "Biaya Kirim";
            this.biayaKirimDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.biayaKirimDataGridViewTextBoxColumn.Name = "biayaKirimDataGridViewTextBoxColumn";
            this.biayaKirimDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // jumlahTransaksiDataGridViewTextBoxColumn
            // 
            this.jumlahTransaksiDataGridViewTextBoxColumn.DataPropertyName = "Jumlah_Transaksi";
            this.jumlahTransaksiDataGridViewTextBoxColumn.HeaderText = "Banyaknya Transaksi";
            this.jumlahTransaksiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.jumlahTransaksiDataGridViewTextBoxColumn.Name = "jumlahTransaksiDataGridViewTextBoxColumn";
            this.jumlahTransaksiDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // totalPemasukkanDataGridViewTextBoxColumn
            // 
            this.totalPemasukkanDataGridViewTextBoxColumn.DataPropertyName = "Total_Pemasukkan";
            this.totalPemasukkanDataGridViewTextBoxColumn.HeaderText = "Total Pemasukkan";
            this.totalPemasukkanDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.totalPemasukkanDataGridViewTextBoxColumn.Name = "totalPemasukkanDataGridViewTextBoxColumn";
            this.totalPemasukkanDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(81, 52);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(89, 81);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 4;
            this.pictureBox6.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(201, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(356, 96);
            this.label13.TabIndex = 2;
            this.label13.Text = "Total Pemasukkan dari Tarif\r\nPembayaran /Tgl 21 Mei 2020\r\n\r\n";
            // 
            // gradientPanel9
            // 
            this.gradientPanel9.ColorBottom = System.Drawing.Color.Cyan;
            this.gradientPanel9.ColorTop = System.Drawing.Color.SkyBlue;
            this.gradientPanel9.Controls.Add(this.label11);
            this.gradientPanel9.Controls.Add(this.pictureBox5);
            this.gradientPanel9.Controls.Add(this.label10);
            this.gradientPanel9.Controls.Add(this.pieChart5);
            this.gradientPanel9.Location = new System.Drawing.Point(64, 2483);
            this.gradientPanel9.Name = "gradientPanel9";
            this.gradientPanel9.Size = new System.Drawing.Size(890, 356);
            this.gradientPanel9.TabIndex = 7;
            this.gradientPanel9.Paint += new System.Windows.Forms.PaintEventHandler(this.gradientPanel9_Paint);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(426, 163);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(338, 144);
            this.label11.TabIndex = 5;
            this.label11.Text = "Berikut adalah responsi pelanggan atas\r\npelayanan kami yang kami survey :\r\n\r\n~ 55" +
    "% Pelanggan Senang\r\n~ 30% Pelanggan Tidak Senang\r\n~ 15% Tanpa Responsi";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(427, 28);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(97, 101);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(530, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(322, 96);
            this.label10.TabIndex = 4;
            this.label10.Text = "Presentase Responsi\r\nPelanggan Atas Pelayanan \r\nYang Diberikan\r\n";
            // 
            // pieChart5
            // 
            this.pieChart5.BackColor = System.Drawing.Color.Transparent;
            this.pieChart5.Location = new System.Drawing.Point(40, 55);
            this.pieChart5.Name = "pieChart5";
            this.pieChart5.Size = new System.Drawing.Size(347, 265);
            this.pieChart5.TabIndex = 0;
            this.pieChart5.Text = "pieChart5";
            this.pieChart5.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.pieChart5_ChildChanged);
            // 
            // gradientPanel8
            // 
            this.gradientPanel8.BackColor = System.Drawing.Color.Black;
            this.gradientPanel8.ColorBottom = System.Drawing.Color.Empty;
            this.gradientPanel8.ColorTop = System.Drawing.Color.Empty;
            this.gradientPanel8.Controls.Add(this.label12);
            this.gradientPanel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gradientPanel8.Location = new System.Drawing.Point(0, 3319);
            this.gradientPanel8.Name = "gradientPanel8";
            this.gradientPanel8.Size = new System.Drawing.Size(1021, 120);
            this.gradientPanel8.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(36, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(269, 85);
            this.label12.TabIndex = 1;
            this.label12.Text = "Alamat Kantor :\r\nSlautan Kelurahan No. 71, Sidoarjo \r\nContact Person : \r\nFani Fad" +
    "illah Hermawan (082228311558)\r\nWirawan Dwi Prasetya (085746757696)";
            // 
            // gradientPanel7
            // 
            this.gradientPanel7.ColorBottom = System.Drawing.Color.Cyan;
            this.gradientPanel7.ColorTop = System.Drawing.Color.SkyBlue;
            this.gradientPanel7.Controls.Add(this.metroGrid4);
            this.gradientPanel7.Controls.Add(this.label7);
            this.gradientPanel7.Controls.Add(this.label6);
            this.gradientPanel7.Controls.Add(this.pictureBox2);
            this.gradientPanel7.Controls.Add(this.pieChart4);
            this.gradientPanel7.Location = new System.Drawing.Point(64, 2900);
            this.gradientPanel7.Name = "gradientPanel7";
            this.gradientPanel7.Size = new System.Drawing.Size(890, 419);
            this.gradientPanel7.TabIndex = 4;
            this.gradientPanel7.Paint += new System.Windows.Forms.PaintEventHandler(this.gradientPanel7_Paint);
            // 
            // metroGrid4
            // 
            this.metroGrid4.AllowUserToAddRows = false;
            this.metroGrid4.AllowUserToDeleteRows = false;
            this.metroGrid4.AllowUserToResizeRows = false;
            this.metroGrid4.AutoGenerateColumns = false;
            this.metroGrid4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.metroGrid4.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.metroGrid4.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid4.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.metroGrid4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.jenispembayaranDataGridViewTextBoxColumn,
            this.jumlahDataGridViewTextBoxColumn1});
            this.metroGrid4.DataSource = this.qPembayaranBindingSource;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid4.DefaultCellStyle = dataGridViewCellStyle20;
            this.metroGrid4.EnableHeadersVisualStyles = false;
            this.metroGrid4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid4.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid4.Location = new System.Drawing.Point(494, 288);
            this.metroGrid4.Name = "metroGrid4";
            this.metroGrid4.ReadOnly = true;
            this.metroGrid4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid4.RowHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.metroGrid4.RowHeadersWidth = 51;
            this.metroGrid4.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid4.RowTemplate.Height = 24;
            this.metroGrid4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid4.Size = new System.Drawing.Size(377, 90);
            this.metroGrid4.TabIndex = 5;
            // 
            // jenispembayaranDataGridViewTextBoxColumn
            // 
            this.jenispembayaranDataGridViewTextBoxColumn.DataPropertyName = "Jenis_pembayaran";
            this.jenispembayaranDataGridViewTextBoxColumn.HeaderText = "Jenis Pembayaran";
            this.jenispembayaranDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.jenispembayaranDataGridViewTextBoxColumn.Name = "jenispembayaranDataGridViewTextBoxColumn";
            this.jenispembayaranDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // jumlahDataGridViewTextBoxColumn1
            // 
            this.jumlahDataGridViewTextBoxColumn1.DataPropertyName = "Jumlah";
            this.jumlahDataGridViewTextBoxColumn1.HeaderText = "Jumlah";
            this.jumlahDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.jumlahDataGridViewTextBoxColumn1.Name = "jumlahDataGridViewTextBoxColumn1";
            this.jumlahDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(80, 246);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(354, 72);
            this.label7.TabIndex = 4;
            this.label7.Text = "Perbandingan pembayaran tunai dengan\r\npembayaran non-tunai (COD) adalah\r\nsebesar " +
    "70 banding 30.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(201, 109);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(312, 96);
            this.label6.TabIndex = 4;
            this.label6.Text = "Presentase Perbandingan \r\nPembayaran Tunai dan \r\nNon-tunai (COD)";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(69, 109);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(101, 96);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pieChart4
            // 
            this.pieChart4.BackColor = System.Drawing.Color.Transparent;
            this.pieChart4.Location = new System.Drawing.Point(556, 26);
            this.pieChart4.Name = "pieChart4";
            this.pieChart4.Size = new System.Drawing.Size(254, 242);
            this.pieChart4.TabIndex = 0;
            this.pieChart4.Text = "pieChart4";
            this.pieChart4.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.pieChart4_ChildChanged);
            // 
            // gradientPanel6
            // 
            this.gradientPanel6.ColorBottom = System.Drawing.Color.Cyan;
            this.gradientPanel6.ColorTop = System.Drawing.Color.SkyBlue;
            this.gradientPanel6.Controls.Add(this.label5);
            this.gradientPanel6.Controls.Add(this.pictureBox1);
            this.gradientPanel6.Controls.Add(this.label4);
            this.gradientPanel6.Controls.Add(this.pieChart3);
            this.gradientPanel6.Location = new System.Drawing.Point(64, 2077);
            this.gradientPanel6.Name = "gradientPanel6";
            this.gradientPanel6.Size = new System.Drawing.Size(890, 324);
            this.gradientPanel6.TabIndex = 5;
            this.gradientPanel6.Paint += new System.Windows.Forms.PaintEventHandler(this.gradientPanel6_Paint);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(382, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(425, 72);
            this.label5.TabIndex = 3;
            this.label5.Text = "Perbandingan barang masuk (diterima) dan \r\nbarang dikirim adalah 40 banding 60 di" +
    "karenakan \r\nproses yang memakan waktu.";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(386, 53);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(67, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(459, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(397, 64);
            this.label4.TabIndex = 1;
            this.label4.Text = "Presentase Perbandingan \r\nBarang Masuk dan Barang Keluar";
            // 
            // pieChart3
            // 
            this.pieChart3.BackColor = System.Drawing.Color.Transparent;
            this.pieChart3.Location = new System.Drawing.Point(28, 25);
            this.pieChart3.Name = "pieChart3";
            this.pieChart3.Size = new System.Drawing.Size(337, 247);
            this.pieChart3.TabIndex = 0;
            this.pieChart3.Text = "pieChart3";
            this.pieChart3.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.pieChart3_ChildChanged);
            // 
            // gradientPanel5
            // 
            this.gradientPanel5.ColorBottom = System.Drawing.Color.Cyan;
            this.gradientPanel5.ColorTop = System.Drawing.Color.SkyBlue;
            this.gradientPanel5.Controls.Add(this.metroGrid3);
            this.gradientPanel5.Controls.Add(this.label3);
            this.gradientPanel5.Controls.Add(this.pieChart2);
            this.gradientPanel5.Location = new System.Drawing.Point(555, 935);
            this.gradientPanel5.Name = "gradientPanel5";
            this.gradientPanel5.Size = new System.Drawing.Size(399, 642);
            this.gradientPanel5.TabIndex = 4;
            this.gradientPanel5.Paint += new System.Windows.Forms.PaintEventHandler(this.gradientPanel5_Paint);
            // 
            // metroGrid3
            // 
            this.metroGrid3.AllowUserToAddRows = false;
            this.metroGrid3.AllowUserToDeleteRows = false;
            this.metroGrid3.AllowUserToResizeRows = false;
            this.metroGrid3.AutoGenerateColumns = false;
            this.metroGrid3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.metroGrid3.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.metroGrid3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.metroGrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.jenisBarangDataGridViewTextBoxColumn,
            this.jumlahDataGridViewTextBoxColumn});
            this.metroGrid3.DataSource = this.qTotalbarangBindingSource;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid3.DefaultCellStyle = dataGridViewCellStyle23;
            this.metroGrid3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.metroGrid3.EnableHeadersVisualStyles = false;
            this.metroGrid3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid3.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid3.Location = new System.Drawing.Point(0, 492);
            this.metroGrid3.Name = "metroGrid3";
            this.metroGrid3.ReadOnly = true;
            this.metroGrid3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.metroGrid3.RowHeadersWidth = 51;
            this.metroGrid3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid3.RowTemplate.Height = 24;
            this.metroGrid3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid3.Size = new System.Drawing.Size(399, 150);
            this.metroGrid3.TabIndex = 2;
            // 
            // jenisBarangDataGridViewTextBoxColumn
            // 
            this.jenisBarangDataGridViewTextBoxColumn.DataPropertyName = "Jenis_Barang";
            this.jenisBarangDataGridViewTextBoxColumn.HeaderText = "Jenis Barang";
            this.jenisBarangDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.jenisBarangDataGridViewTextBoxColumn.Name = "jenisBarangDataGridViewTextBoxColumn";
            this.jenisBarangDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // jumlahDataGridViewTextBoxColumn
            // 
            this.jumlahDataGridViewTextBoxColumn.DataPropertyName = "Jumlah";
            this.jumlahDataGridViewTextBoxColumn.HeaderText = "Jumlah";
            this.jumlahDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.jumlahDataGridViewTextBoxColumn.Name = "jumlahDataGridViewTextBoxColumn";
            this.jumlahDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(102, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(187, 56);
            this.label3.TabIndex = 1;
            this.label3.Text = "Presentase Barang\r\nTransaksi\r\n";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pieChart2
            // 
            this.pieChart2.BackColor = System.Drawing.Color.Transparent;
            this.pieChart2.Location = new System.Drawing.Point(35, 144);
            this.pieChart2.Name = "pieChart2";
            this.pieChart2.Size = new System.Drawing.Size(337, 274);
            this.pieChart2.TabIndex = 0;
            this.pieChart2.Text = "pieChart2";
            this.pieChart2.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.pieChart2_ChildChanged);
            // 
            // gradientPanel4
            // 
            this.gradientPanel4.ColorBottom = System.Drawing.Color.Cyan;
            this.gradientPanel4.ColorTop = System.Drawing.Color.SkyBlue;
            this.gradientPanel4.Controls.Add(this.metroGrid2);
            this.gradientPanel4.Controls.Add(this.metroGrid1);
            this.gradientPanel4.Controls.Add(this.label2);
            this.gradientPanel4.Controls.Add(this.pieChart1);
            this.gradientPanel4.Location = new System.Drawing.Point(64, 935);
            this.gradientPanel4.Name = "gradientPanel4";
            this.gradientPanel4.Size = new System.Drawing.Size(399, 642);
            this.gradientPanel4.TabIndex = 3;
            this.gradientPanel4.Paint += new System.Windows.Forms.PaintEventHandler(this.gradientPanel4_Paint);
            // 
            // metroGrid2
            // 
            this.metroGrid2.AllowUserToAddRows = false;
            this.metroGrid2.AllowUserToDeleteRows = false;
            this.metroGrid2.AllowUserToResizeRows = false;
            this.metroGrid2.AutoGenerateColumns = false;
            this.metroGrid2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.metroGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.namajabatanDataGridViewTextBoxColumn1,
            this.keteranganDataGridViewTextBoxColumn1,
            this.jumlahKurirDataGridViewTextBoxColumn});
            this.metroGrid2.DataSource = this.qJumlahKurirBindingSource;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid2.DefaultCellStyle = dataGridViewCellStyle26;
            this.metroGrid2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.metroGrid2.EnableHeadersVisualStyles = false;
            this.metroGrid2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.Location = new System.Drawing.Point(0, 412);
            this.metroGrid2.Name = "metroGrid2";
            this.metroGrid2.ReadOnly = true;
            this.metroGrid2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.metroGrid2.RowHeadersWidth = 51;
            this.metroGrid2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid2.RowTemplate.Height = 24;
            this.metroGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid2.Size = new System.Drawing.Size(399, 107);
            this.metroGrid2.TabIndex = 3;
            // 
            // namajabatanDataGridViewTextBoxColumn1
            // 
            this.namajabatanDataGridViewTextBoxColumn1.DataPropertyName = "nama_jabatan";
            this.namajabatanDataGridViewTextBoxColumn1.HeaderText = "Jabatan";
            this.namajabatanDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.namajabatanDataGridViewTextBoxColumn1.Name = "namajabatanDataGridViewTextBoxColumn1";
            this.namajabatanDataGridViewTextBoxColumn1.ReadOnly = true;
            this.namajabatanDataGridViewTextBoxColumn1.Width = 125;
            // 
            // keteranganDataGridViewTextBoxColumn1
            // 
            this.keteranganDataGridViewTextBoxColumn1.DataPropertyName = "keterangan";
            this.keteranganDataGridViewTextBoxColumn1.HeaderText = "Keterangan";
            this.keteranganDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.keteranganDataGridViewTextBoxColumn1.Name = "keteranganDataGridViewTextBoxColumn1";
            this.keteranganDataGridViewTextBoxColumn1.ReadOnly = true;
            this.keteranganDataGridViewTextBoxColumn1.Width = 125;
            // 
            // jumlahKurirDataGridViewTextBoxColumn
            // 
            this.jumlahKurirDataGridViewTextBoxColumn.DataPropertyName = "Jumlah_Kurir";
            this.jumlahKurirDataGridViewTextBoxColumn.HeaderText = "Jumlah";
            this.jumlahKurirDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.jumlahKurirDataGridViewTextBoxColumn.Name = "jumlahKurirDataGridViewTextBoxColumn";
            this.jumlahKurirDataGridViewTextBoxColumn.ReadOnly = true;
            this.jumlahKurirDataGridViewTextBoxColumn.Width = 125;
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToAddRows = false;
            this.metroGrid1.AllowUserToDeleteRows = false;
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.AutoGenerateColumns = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.namajabatanDataGridViewTextBoxColumn,
            this.keteranganDataGridViewTextBoxColumn,
            this.jumahDataGridViewTextBoxColumn});
            this.metroGrid1.DataSource = this.qjabatanBindingSource;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle29;
            this.metroGrid1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(0, 519);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.ReadOnly = true;
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.metroGrid1.RowHeadersWidth = 51;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.RowTemplate.Height = 24;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(399, 123);
            this.metroGrid1.TabIndex = 2;
            // 
            // namajabatanDataGridViewTextBoxColumn
            // 
            this.namajabatanDataGridViewTextBoxColumn.DataPropertyName = "nama_jabatan";
            this.namajabatanDataGridViewTextBoxColumn.HeaderText = "Jabatan";
            this.namajabatanDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.namajabatanDataGridViewTextBoxColumn.Name = "namajabatanDataGridViewTextBoxColumn";
            this.namajabatanDataGridViewTextBoxColumn.ReadOnly = true;
            this.namajabatanDataGridViewTextBoxColumn.Width = 125;
            // 
            // keteranganDataGridViewTextBoxColumn
            // 
            this.keteranganDataGridViewTextBoxColumn.DataPropertyName = "keterangan";
            this.keteranganDataGridViewTextBoxColumn.HeaderText = "Keterangan";
            this.keteranganDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.keteranganDataGridViewTextBoxColumn.Name = "keteranganDataGridViewTextBoxColumn";
            this.keteranganDataGridViewTextBoxColumn.ReadOnly = true;
            this.keteranganDataGridViewTextBoxColumn.Width = 125;
            // 
            // jumahDataGridViewTextBoxColumn
            // 
            this.jumahDataGridViewTextBoxColumn.DataPropertyName = "Jumah";
            this.jumahDataGridViewTextBoxColumn.HeaderText = "Jumah";
            this.jumahDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.jumahDataGridViewTextBoxColumn.Name = "jumahDataGridViewTextBoxColumn";
            this.jumahDataGridViewTextBoxColumn.ReadOnly = true;
            this.jumahDataGridViewTextBoxColumn.Width = 125;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(112, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(195, 56);
            this.label2.TabIndex = 1;
            this.label2.Text = "Presentase Pekerja \r\ndi Next Agency";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pieChart1
            // 
            this.pieChart1.BackColor = System.Drawing.Color.Transparent;
            this.pieChart1.Location = new System.Drawing.Point(28, 120);
            this.pieChart1.Name = "pieChart1";
            this.pieChart1.Size = new System.Drawing.Size(337, 274);
            this.pieChart1.TabIndex = 0;
            this.pieChart1.Text = "pieChart1";
            this.pieChart1.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.pieChart1_ChildChanged);
            // 
            // gradientPanel3
            // 
            this.gradientPanel3.ColorBottom = System.Drawing.Color.Cyan;
            this.gradientPanel3.ColorTop = System.Drawing.Color.SkyBlue;
            this.gradientPanel3.Controls.Add(this.label1);
            this.gradientPanel3.Controls.Add(this.dataGridView1);
            this.gradientPanel3.Controls.Add(this.cartesianChart1);
            this.gradientPanel3.Location = new System.Drawing.Point(64, 414);
            this.gradientPanel3.Name = "gradientPanel3";
            this.gradientPanel3.Size = new System.Drawing.Size(890, 494);
            this.gradientPanel3.TabIndex = 2;
            this.gradientPanel3.Paint += new System.Windows.Forms.PaintEventHandler(this.gradientPanel3_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(309, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(294, 32);
            this.label1.TabIndex = 2;
            this.label1.Text = "Total Transaksi Pertahun";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView1.Location = new System.Drawing.Point(0, 340);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(890, 154);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // cartesianChart1
            // 
            this.cartesianChart1.BackColor = System.Drawing.Color.Transparent;
            this.cartesianChart1.Location = new System.Drawing.Point(37, 103);
            this.cartesianChart1.Name = "cartesianChart1";
            this.cartesianChart1.Size = new System.Drawing.Size(826, 215);
            this.cartesianChart1.TabIndex = 0;
            this.cartesianChart1.Text = "cartesianChart1";
            this.cartesianChart1.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.cartesianChart1_ChildChanged);
            // 
            // gradientPanel2
            // 
            this.gradientPanel2.ColorBottom = System.Drawing.Color.Cyan;
            this.gradientPanel2.ColorTop = System.Drawing.Color.SkyBlue;
            this.gradientPanel2.Controls.Add(this.pictureBox4);
            this.gradientPanel2.Controls.Add(this.label9);
            this.gradientPanel2.Controls.Add(this.label8);
            this.gradientPanel2.Controls.Add(this.pictureBox3);
            this.gradientPanel2.Location = new System.Drawing.Point(64, 133);
            this.gradientPanel2.Name = "gradientPanel2";
            this.gradientPanel2.Size = new System.Drawing.Size(890, 246);
            this.gradientPanel2.TabIndex = 1;
            this.gradientPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.gradientPanel2_Paint);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(666, 23);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(197, 190);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(292, 116);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(311, 70);
            this.label9.TabIndex = 4;
            this.label9.Text = "\"Connecting people to people \r\nwith our expedition\" - Nokia";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(292, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(314, 32);
            this.label8.TabIndex = 2;
            this.label8.Text = "NEXT-AGENCY Dashboard";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(37, 23);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(190, 190);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // gradientPanel1
            // 
            this.gradientPanel1.ColorBottom = System.Drawing.Color.Cyan;
            this.gradientPanel1.ColorTop = System.Drawing.Color.SkyBlue;
            this.gradientPanel1.Controls.Add(this.button3);
            this.gradientPanel1.Controls.Add(this.button2);
            this.gradientPanel1.Controls.Add(this.button1);
            this.gradientPanel1.Location = new System.Drawing.Point(64, 50);
            this.gradientPanel1.Name = "gradientPanel1";
            this.gradientPanel1.Size = new System.Drawing.Size(890, 42);
            this.gradientPanel1.TabIndex = 0;
            this.gradientPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.gradientPanel1_Paint);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(242, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(145, 37);
            this.button3.TabIndex = 2;
            this.button3.Text = " Pencapaian ";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(122, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(123, 37);
            this.button2.TabIndex = 1;
            this.button2.Text = "Dashboard";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(28, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 37);
            this.button1.TabIndex = 0;
            this.button1.Text = "Home";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1042, 1055);
            this.Controls.Add(this.gradientPanel10);
            this.Controls.Add(this.gradientPanel9);
            this.Controls.Add(this.gradientPanel8);
            this.Controls.Add(this.gradientPanel7);
            this.Controls.Add(this.gradientPanel6);
            this.Controls.Add(this.gradientPanel5);
            this.Controls.Add(this.gradientPanel4);
            this.Controls.Add(this.gradientPanel3);
            this.Controls.Add(this.gradientPanel2);
            this.Controls.Add(this.gradientPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Next-Agency Dashboard";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.eksDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qjabatanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qJumlahKurirBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qTotalbarangBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qPembayaranBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qTarifBindingSource)).EndInit();
            this.gradientPanel10.ResumeLayout(false);
            this.gradientPanel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.gradientPanel9.ResumeLayout(false);
            this.gradientPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.gradientPanel8.ResumeLayout(false);
            this.gradientPanel8.PerformLayout();
            this.gradientPanel7.ResumeLayout(false);
            this.gradientPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.gradientPanel6.ResumeLayout(false);
            this.gradientPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.gradientPanel5.ResumeLayout(false);
            this.gradientPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).EndInit();
            this.gradientPanel4.ResumeLayout(false);
            this.gradientPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            this.gradientPanel3.ResumeLayout(false);
            this.gradientPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.gradientPanel2.ResumeLayout(false);
            this.gradientPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.gradientPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private GradientPanel gradientPanel8;
        private System.Windows.Forms.Label label12;
        private EksDataSet eksDataSet;
        private System.Windows.Forms.BindingSource qjabatanBindingSource;
        private EksDataSetTableAdapters.QjabatanTableAdapter qjabatanTableAdapter;
        private System.Windows.Forms.BindingSource qJumlahKurirBindingSource;
        private EksDataSetTableAdapters.QJumlahKurirTableAdapter qJumlahKurirTableAdapter;
        private System.Windows.Forms.BindingSource qTotalbarangBindingSource;
        private EksDataSetTableAdapters.QTotal_barangTableAdapter qTotal_barangTableAdapter;
        private System.Windows.Forms.BindingSource qPembayaranBindingSource;
        private EksDataSetTableAdapters.QPembayaranTableAdapter qPembayaranTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private GradientPanel gradientPanel1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox4;
        private GradientPanel gradientPanel2;
        private LiveCharts.WinForms.CartesianChart cartesianChart1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private GradientPanel gradientPanel3;
        private LiveCharts.WinForms.PieChart pieChart1;
        private System.Windows.Forms.Label label2;
        private MetroFramework.Controls.MetroGrid metroGrid1;
        private System.Windows.Forms.DataGridViewTextBoxColumn namajabatanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn keteranganDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jumahDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroGrid metroGrid2;
        private System.Windows.Forms.DataGridViewTextBoxColumn namajabatanDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn keteranganDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn jumlahKurirDataGridViewTextBoxColumn;
        private GradientPanel gradientPanel4;
        private LiveCharts.WinForms.PieChart pieChart2;
        private System.Windows.Forms.Label label3;
        private MetroFramework.Controls.MetroGrid metroGrid3;
        private System.Windows.Forms.DataGridViewTextBoxColumn jenisBarangDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jumlahDataGridViewTextBoxColumn;
        private GradientPanel gradientPanel5;
        private LiveCharts.WinForms.PieChart pieChart3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label5;
        private GradientPanel gradientPanel6;
        private LiveCharts.WinForms.PieChart pieChart4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private MetroFramework.Controls.MetroGrid metroGrid4;
        private System.Windows.Forms.DataGridViewTextBoxColumn jenispembayaranDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jumlahDataGridViewTextBoxColumn1;
        private GradientPanel gradientPanel7;
        private LiveCharts.WinForms.PieChart pieChart5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label11;
        private GradientPanel gradientPanel9;
        private GradientPanel gradientPanel10;
        private MetroFramework.Controls.MetroGrid metroGrid5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.BindingSource qTarifBindingSource;
        private EksDataSetTableAdapters.QTarifTableAdapter qTarifTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn namajenispengirimanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn biayaKirimDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jumlahTransaksiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalPemasukkanDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label14;
    }
}